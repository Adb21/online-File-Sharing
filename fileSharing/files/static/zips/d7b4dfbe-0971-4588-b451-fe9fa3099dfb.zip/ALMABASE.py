from fuzzywuzzy import fuzz 
from rapidfuzz import fuzz as rfuzz
import threading
import itertools
from itertools import permutations

###constraints
#1) if first_name + last_name + email has match > 80%, then => score = +1 (DONE)
#2) if same class year, then => score = +1 | elif either is None, then => score = score | else no match, then => score = -1
#3) Rule 2 for birthday

##Results
# if total_score > 1, then profiles are duplicate

##I/O
# input : Dict
# output : Dict [result,total_match_score,matching_attributes,ignored_attributes]

##Optimization
# fast processing [threads on constraints]
# support more fields [kwargs]

### algos used : fuzzywuzzy and rapidfuzz

#string fields use fuzzy 

def find_duplicates(profiles=[],fields=[]):
	total_score = 0
	# combined_score = 0
	matching_attributes=[]
	non_matching_attributes=[]
	ignored_attributes=[]
	
	strList=['email','first_name','last_name']
	cmb1 = []
	cmb2 = []
	
	for field in fields:
		if profiles[0][field] == None or profiles[1][field] == None:
			ignored_attributes.append(field)
			continue

		if field == 'email' or field == 'first_name' or field == 'last_name':
			cmb1=cmb1.append(profiles[0][field])
			cmb2=cmb2.append(profiles[1][field])
			
		if field == 'class_year' or field == 'date_of_birth':
			if profiles[0][field] == profiles[1][field]:
				total_score += 1
				matching_attributes.append(field)
			else:
				total_score -= 1
				non_matching_attributes.append(field)
		data.clear()

	data.append(cmb1)
	data.append(cmb2)
	

	ind = strScore.index(max(strScore))

	if len(matching_attributes)==0:
		matching_attributes.append(None)
	if len(non_matching_attributes)==0:
		non_matching_attributes.append(None)
	if len(ignored_attributes)==0:
		ignored_attributes.append(None)

	print(f"total score is {total_score}")
	print(f"matching_attributes is {matching_attributes}")
	print(f"non_matching_attributes is {non_matching_attributes}")
	print(f"ignored_attributes is {ignored_attributes}")

def checkCombinations(cmb1 = [],cmb2 = []):
	strScore = []

	# case 0) ['email','first_name','last_name']
	strScore.append(getScore(
		f"{cmb1['email']}{cmb1['first_name']}{cmb1['last_name']}",
    	f"{cmb2['email']}{cmb2['first_name']}{cmb2['last_name']}"
    ))

    # case 1) ['email','first_name']
	strScore.append(getScore(
		f"{cmb1['email']}{cmb1['first_name']}",
    	f"{cmb2['email']}{cmb2['first_name']}"
    ))

    # case 2) ['email','last_name']
	strScore.append(getScore(
		f"{cmb1['email']}{cmb1['last_name']}",
    	f"{cmb2['email']}{cmb2['last_name']}"
    ))

    # case 3) ['first_name','last_name']
	strScore.append(getScore(
		f"{cmb1['first_name']}{cmb1['last_name']}",
    	f"{cmb2['first_name']}{cmb2['last_name']}"
    ))
	
	print(strScore)
	case = strScore.index(max(strScore))
	print(case)

def getScore(str1,str2):
	print(str1,str2)
	return rfuzz.partial_ratio(str1,str2)

# p1 = { id: 1, 'email': 'knowkanhai@gmail.com', 'first_name': 'Kanhai', 'last_name': 'Shah', 'class_year': 2012, 'date_of_birth': '1990-10-11' }
# p2 = { id: 2, 'email': 'knowkanhai@gmail.com', 'first_name': 'Kanhai1', 'last_name': 'Shah', 'class_year': 2012, 'date_of_birth': '1990-10-11'}

# p1 = { id: 1, 'email': 'knowkanhai@gmail.com', 'first_name': 'Kanhai', 'last_name': 'Shah', 'class_year': None, 'date_of_birth': None}
# p2 = { id: 2, 'email': 'knowkanhai@gmail.com', 'first_name': 'Kanhai1', 'last_name': 'Shah', 'class_year': 2012, 'date_of_birth': '1990-10-11'}

p1 = { id: 1, 'email': 'knowkanhai@gmail.com', 'first_name': 'Kanhai', 'last_name': 'Shah', 'class_year': None, 'date_of_birth': None}
p2 = { id: 2, 'email': 'knowkanhai+donotcompare@gmail.com', 'first_name': 'Kanhai1', 'last_name': 'Shah', 'class_year': 2012, 'date_of_birth': '1990-10-11'}

profiles = [p1,p2]
fields = ['first_name','last_name','email','class_year','date_of_birth']
# find_duplicates(profiles,fields)

cmb1 = {'email':'knowkanhai@gmail.com','first_name':'Kanhai','last_name':'Shah'}
cmb2 = {'email':'knowkanhai+donotcompare@gmail.com','first_name':'Kanhai1','last_name':'Shah'}
checkCombinations(cmb1,cmb2 )

